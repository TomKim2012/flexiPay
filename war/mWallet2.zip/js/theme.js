	$('a[data-toggle=tooltip]').tooltip();
