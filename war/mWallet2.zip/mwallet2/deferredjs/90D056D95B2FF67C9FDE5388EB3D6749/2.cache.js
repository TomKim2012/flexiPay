function Bgb(a){!a.j&&(a.j=ogb(a));return a.j}
NO(616,1,nXb);_.ob=function Ogb(){Scb(this.b,Bgb(this.a.a))};OXb(eh)(2);